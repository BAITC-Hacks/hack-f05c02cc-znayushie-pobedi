from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    session_id: str | None = None


class ProposalRequest(BaseModel):
    product_id: str
    quantity: int = Field(ge=1, le=1000)


class ConfirmRequest(BaseModel):
    confirm: bool


class Proposal(BaseModel):
    proposal_id: str
    product_id: str
    quantity: int
    expires_at: datetime
    product: dict[str, Any]


class ChatResponse(BaseModel):
    session_id: str
    answer: str
    products: list[dict[str, Any]]
    pending_action: Proposal | None = None
