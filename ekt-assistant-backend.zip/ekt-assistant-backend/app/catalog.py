"""Simple JSON catalog. Replace the sample JSON with validated site data for production."""
import json
import re
from pathlib import Path
from typing import Any

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "products.json"


class Catalog:
    def __init__(self, path: Path = DATA_FILE):
        rows = json.loads(path.read_text(encoding="utf-8-sig"))
        self.products: dict[str, dict[str, Any]] = {row["id"]: row for row in rows}
        if len(self.products) != len(rows):
            raise ValueError("Duplicate product ID")

    def get(self, product_id: str) -> dict[str, Any] | None:
        return self.products.get(product_id)

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        terms = [term for term in re.findall(r"[\w×.,()-]+", query.casefold()) if len(term) >= 2]
        if not terms:
            return []
        ranked = []
        for product in self.products.values():
            name = product["name"].casefold()
            searchable = " ".join(str(v) for v in [product["id"], product["sku"], product["name"], product["category"], product["brand"], product["description"], *product["properties"].values()]).casefold()
            score = sum((3 if term in name else 1) for term in terms if term in searchable)
            if score:
                ranked.append((score, product))
        ranked.sort(key=lambda pair: (-pair[0], pair[1]["id"]))
        return [product for _, product in ranked[:limit]]

    def alternatives(self, product_id: str, limit: int = 5) -> list[dict[str, Any]]:
        original = self.get(product_id)
        if original is None:
            return []
        candidates = [p for p in self.products.values() if p["id"] != product_id and p["category"] == original["category"] and p["stock"] > 0]
        candidates.sort(key=lambda p: (-sum(p["properties"].get(k) == v for k, v in original["properties"].items()), p["id"]))
        return candidates[:limit]

