"""Catalog-grounded answers; model output never controls cart mutations."""
import json
import os
from typing import Any

from fastapi import HTTPException


def answer(message: str, products: list[dict[str, Any]]) -> str:
    if not products:
        return "В демонстрационном каталоге ничего не найдено. Уточните артикул, название или характеристику. Данные ekt.kz здесь не подключены."
    provider = os.getenv("AI_PROVIDER", "demo").lower()
    if provider == "demo":
        lines = [f"{p['name']} ({p['sku']}): {p['price_kzt']} ₸/{p['unit']}; " + (f"в демо-каталоге {p['stock']} {p['unit']}" if p['stock'] else "нет в демо-наличии") for p in products]
        return "Нашёл в демонстрационном каталоге:\n" + "\n".join(lines) + "\nДля аналогов откройте карточку товара. Цена и остаток не являются данными ekt.kz."
    if provider not in {"openai", "nvidia"}:
        raise HTTPException(500, "Invalid AI_PROVIDER")
    key = os.getenv("OPENAI_API_KEY" if provider == "openai" else "NVIDIA_API_KEY")
    model = os.getenv("OPENAI_MODEL" if provider == "openai" else "NVIDIA_MODEL")
    if not key or not model:
        raise HTTPException(503, f"{provider} key or model is not configured")
    try:
        from openai import OpenAI
        context = json.dumps(products, ensure_ascii=False)
        instructions = ("Ты консультант по демонстрационному электротехническому каталогу. Отвечай по-русски только на основании JSON. "
                        "Цена и остаток демонстрационные, не актуальные данные ekt.kz. Если фактов нет, прямо скажи об этом. "
                        "Никогда не говори, что товар уже добавлен в корзину. Добавление происходит только через отдельное подтверждение сервером.")
        client = OpenAI(api_key=key, timeout=15, **({"base_url": "https://integrate.api.nvidia.com/v1"} if provider == "nvidia" else {}))
        if provider == "openai":
            response = client.responses.create(model=model, instructions=instructions, input=f"Каталог: {context}\nВопрос: {message}", store=False)
            return response.output_text
        response = client.chat.completions.create(model=model, messages=[{"role": "system", "content": instructions}, {"role": "user", "content": f"Каталог: {context}\nВопрос: {message}"}])
        return response.choices[0].message.content or "Не удалось сформировать ответ."
    except Exception as exc:
        raise HTTPException(502, f"AI provider request failed: {type(exc).__name__}") from exc
