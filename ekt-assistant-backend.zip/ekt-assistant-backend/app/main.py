"""Run: uvicorn app.main:app --reload"""
import os
import re

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from .assistant import answer
from .catalog import Catalog
from .models import ChatRequest, ChatResponse, ConfirmRequest, Proposal, ProposalRequest
from .sessions import SessionStore

load_dotenv(".env.local")
load_dotenv(".env")

catalog = Catalog()
store = SessionStore(catalog)
app = FastAPI(title="ECT catalog assistant demo", version="0.1.0")
origins = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST", "DELETE"], allow_headers=["Content-Type"])


@app.get("/health")
def health():
    return {"status": "ok", "catalog": "demo", "products": len(catalog.products)}


@app.get("/api/products/search")
def search_products(q: str = Query(min_length=1), limit: int = Query(5, ge=1, le=20)):
    return {"products": catalog.search(q, limit), "source": "demo-json"}


@app.get("/api/products/{product_id}")
def get_product(product_id: str):
    product = catalog.get(product_id)
    if product is None:
        raise HTTPException(404, "Unknown product")
    return product


@app.get("/api/products/{product_id}/alternatives")
def get_alternatives(product_id: str):
    if catalog.get(product_id) is None:
        raise HTTPException(404, "Unknown product")
    return {"products": catalog.alternatives(product_id), "note": "Same-category suggestions, not verified interchangeable substitutes"}


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    session = store.get(request.session_id) if request.session_id else store.create()
    products = catalog.search(request.message)
    if not products and session.last_product_ids:
        previous = catalog.get(session.last_product_ids[0])
        if re.search(r"аналог|замен|похож", request.message.casefold()):
            products = catalog.alternatives(previous["id"]) if previous else []
        elif re.search(r"налич|цен|характер|сколько|подроб", request.message.casefold()):
            products = [previous] if previous else []
    if products:
        session.last_product_ids = [p["id"] for p in products]
    text = answer(request.message, products)
    proposal = None
    # Add intent may create a proposal. Chat, including 'yes', can never confirm one.
    if re.search(r"\b(добавь|положи|добавить|положить)\b", request.message.casefold()):
        selected = [p for p in products if p["id"].casefold() in request.message.casefold() or p["sku"].casefold() in request.message.casefold()]
        if len(selected) == 1 and selected[0]["stock"] > store.get(session.id).cart.get(selected[0]["id"], 0):
            proposal = store.propose(session.id, selected[0]["id"], 1)
            text += "\nПодтвердите добавление отдельной кнопкой. Пока корзина не изменена."
        else:
            text += "\nДля добавления выберите товар и количество. Корзина не изменена."
    return {"session_id": session.id, "answer": text, "products": products, "pending_action": proposal}


@app.get("/api/sessions/{session_id}/cart")
def get_cart(session_id: str):
    return store.cart(session_id)


@app.post("/api/sessions/{session_id}/cart/proposals", response_model=Proposal, status_code=201)
def create_proposal(session_id: str, request: ProposalRequest):
    return store.propose(session_id, request.product_id, request.quantity)


@app.post("/api/sessions/{session_id}/cart/proposals/{proposal_id}/confirm")
def confirm_proposal(session_id: str, proposal_id: str, request: ConfirmRequest):
    return store.confirm(session_id, proposal_id, request.confirm)


@app.delete("/api/sessions/{session_id}/cart/proposals/{proposal_id}", status_code=204)
def cancel_proposal(session_id: str, proposal_id: str):
    store.cancel(session_id, proposal_id)

