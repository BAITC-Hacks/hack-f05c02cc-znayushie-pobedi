"""In-memory demo sessions. A lock protects cart mutations and proposal consumption."""
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from threading import RLock
from uuid import uuid4

from fastapi import HTTPException

from .catalog import Catalog

TTL = timedelta(minutes=10)


@dataclass
class Session:
    id: str
    cart: dict[str, int] = field(default_factory=dict)
    last_product_ids: list[str] = field(default_factory=list)
    proposals: dict[str, dict] = field(default_factory=dict)


class SessionStore:
    def __init__(self, catalog: Catalog):
        self.catalog = catalog
        self.sessions: dict[str, Session] = {}
        self.lock = RLock()

    def get(self, session_id: str) -> Session:
        with self.lock:
            session = self.sessions.get(session_id)
            if not session:
                raise HTTPException(404, "Unknown session")
            return session

    def create(self) -> Session:
        with self.lock:
            session = Session(str(uuid4()))
            self.sessions[session.id] = session
            return session

    def cart(self, session_id: str) -> dict:
        with self.lock:
            session = self.get(session_id)
            items = [{"product": self.catalog.get(pid), "quantity": qty, "subtotal_kzt": self.catalog.get(pid)["price_kzt"] * qty} for pid, qty in session.cart.items()]
            return {"session_id": session_id, "items": items, "total_kzt": sum(i["subtotal_kzt"] for i in items)}

    def propose(self, session_id: str, product_id: str, quantity: int) -> dict:
        with self.lock:
            session = self.get(session_id)
            product = self.catalog.get(product_id)
            if product is None:
                raise HTTPException(404, "Unknown product")
            if quantity < 1 or quantity > 1000:
                raise HTTPException(422, "Quantity must be from 1 to 1000")
            if session.cart.get(product_id, 0) + quantity > product["stock"]:
                raise HTTPException(409, "Insufficient stock in demo catalog")
            proposal_id = str(uuid4())
            result = {"proposal_id": proposal_id, "product_id": product_id, "quantity": quantity,
                      "expires_at": datetime.now(timezone.utc) + TTL, "product": product}
            session.proposals[proposal_id] = {"status": "pending", "data": result}
            return result

    def confirm(self, session_id: str, proposal_id: str, confirmed: bool) -> dict:
        with self.lock:
            session = self.get(session_id)
            entry = session.proposals.get(proposal_id)
            if entry is None:
                raise HTTPException(404, "Unknown proposal for this session")
            if confirmed is not True:
                raise HTTPException(422, "Explicit confirm: true is required")
            if entry["status"] == "confirmed":
                return entry["cart"]  # frontend retries are idempotent
            if entry["status"] != "pending":
                raise HTTPException(409, "Proposal is no longer pending")
            proposal = entry["data"]
            if datetime.now(timezone.utc) >= proposal["expires_at"]:
                entry["status"] = "expired"
                raise HTTPException(409, "Proposal expired")
            product = self.catalog.get(proposal["product_id"])
            if product is None or session.cart.get(proposal["product_id"], 0) + proposal["quantity"] > product["stock"]:
                raise HTTPException(409, "Product is unavailable or stock has changed")
            session.cart[proposal["product_id"]] = session.cart.get(proposal["product_id"], 0) + proposal["quantity"]
            entry["status"] = "confirmed"
            entry["cart"] = self.cart(session_id)
            return entry["cart"]

    def cancel(self, session_id: str, proposal_id: str) -> None:
        with self.lock:
            entry = self.get(session_id).proposals.get(proposal_id)
            if entry is None:
                raise HTTPException(404, "Unknown proposal for this session")
            if entry["status"] != "pending":
                raise HTTPException(409, "Proposal is no longer pending")
            entry["status"] = "cancelled"

