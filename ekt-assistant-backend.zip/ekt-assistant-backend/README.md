# Каталожный чат-ассистент EKT — демо backend

Минимальный FastAPI сервер с поиском в локальном JSON, сессиями в памяти, демо-корзиной и обязательным двухшаговым подтверждением добавления. **Каталог, цены и остатки здесь вымышленные; данные ekt.kz не подключены.** Поиск аналогов предлагает товары той же категории по похожим свойствам, но не подтверждает их техническую взаимозаменяемость.

## Структура

```text
app/
  __init__.py
  main.py        # HTTP API, CORS и сессия чата
  models.py      # схемы запросов и ответов
  catalog.py     # чтение JSON, поиск и похожие товары
  sessions.py    # сессии, предложения и корзина в памяти
  assistant.py   # ответы по найденным товарам, необязательный LLM
data/
  products.json  # демонстрационные товары
tests/
  test_api.py    # сценарии подтверждения, изоляции, остатков
.env.example
requirements.txt
README.md
```

## Запуск

Из каталога `ekt-assistant-backend` (Python 3.10+):

```powershell
py -3 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
Copy-Item .env.example .env
.venv\Scripts\python -m uvicorn app.main:app --reload
```

Сервер: `http://127.0.0.1:8000`; интерактивная схема: `http://127.0.0.1:8000/docs`; `GET /health` возвращает состояние и число демо-товаров. Для проверки: `.venv\Scripts\python -m pytest -q`. Переменные читаются из `.env.local`, затем `.env`. `.env` и `.env.local` с ключами не публикуйте.

По умолчанию `AI_PROVIDER=demo`: ответ собирается из JSON без сети и ключей. Для внешнего ИИ задайте `AI_PROVIDER=openai`, `OPENAI_API_KEY` и `OPENAI_MODEL` либо `AI_PROVIDER=nvidia`, `NVIDIA_API_KEY` и `NVIDIA_MODEL`. При отсутствии ключа/модели сервер вернёт 503, при ошибке провайдера 502. NVIDIA используется через совместимый OpenAI API endpoint. Модель получает только результаты поиска; она не вызывает запись в корзину. `CORS_ORIGINS` задаёт разрешённые origin фронтенда через запятую (по умолчанию localhost:3000 и localhost:5173).

## Контракт API для фронтенда

Все тела запросов и ответов — JSON, кроме успешного `DELETE` без тела. При ошибке FastAPI возвращает `{"detail": ...}`. `session_id` — UUID, который фронтенд сохраняет после первого сообщения и передаёт в следующих запросах. Неизвестная сессия даёт 404.

| Метод и путь | Запрос | Результат |
| --- | --- | --- |
| `POST /api/chat` | `{"message":"C16","session_id":null}`; `session_id` можно опустить | `{"session_id":string,"answer":string,"products":Product[],"pending_action":Proposal|null}` |
| `GET /api/products/search?q=C16&limit=5` | `q` обязателен; `limit` 1–20, по умолчанию 5 | `{"products":Product[],"source":"demo-json"}` |
| `GET /api/products/{product_id}` | ID товара | `Product`; 404 при отсутствии |
| `GET /api/products/{product_id}/alternatives` | ID товара | `{"products":Product[],"note":string}`; 404 при отсутствии |
| `GET /api/sessions/{session_id}/cart` | ID сессии | `Cart` |
| `POST /api/sessions/{session_id}/cart/proposals` | `{"product_id":string,"quantity":integer}` (1–1000) | `Proposal`, код 201; корзина не меняется |
| `POST /api/sessions/{session_id}/cart/proposals/{proposal_id}/confirm` | **`{"confirm":true}`** | `Cart`; изменение корзины происходит только здесь |
| `DELETE /api/sessions/{session_id}/cart/proposals/{proposal_id}` | без тела | код 204; отменяет ожидающее предложение |

`Product` содержит `id`, `sku`, `name`, `category`, `brand`, `unit`, `price_kzt`, `stock`, `properties`, `description`. `Proposal` содержит `proposal_id`, `product_id`, `quantity`, `expires_at` (ISO 8601 UTC), `product`. `Cart` содержит `session_id`, `items` (каждый: `product`, `quantity`, `subtotal_kzt`) и `total_kzt`.

### Порядок действий

1. Отправьте `POST /api/chat` без `session_id`; сохраните возвращённый ID. Чат отвечает на вопросы и помнит последние найденные товары для уточнений о цене, наличии и аналогах, но не добавляет товар. Сообщение вроде `добавь DEMO-004` может вернуть `pending_action` для **одной** единицы товара, если артикул или ID однозначно найден.
2. Для выбора товара и количества вызовите `POST /api/sessions/{session_id}/cart/proposals`. Покажите пользователю товар, количество и отдельную кнопку «Подтвердить добавление»; предложение живёт 10 минут. Кнопка «Отмена» вызывает `DELETE`.
3. Только после явного нажатия отправьте `POST .../confirm` с `{"confirm":true}`. `false`, отсутствие поля и простое «да» в чате не подтверждают добавление. Повтор того же успешного confirm возвращает ту же корзину и не добавляет второй раз.

Пример запроса (PowerShell):

```powershell
$chat = Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/chat -ContentType 'application/json; charset=utf-8' -Body '{"message":"C16"}'
$sessionId = $chat.session_id
$proposal = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8000/api/sessions/$sessionId/cart/proposals" -ContentType 'application/json' -Body '{"product_id":"demo-breaker-16a","quantity":2}'
# Отрисуйте предложение и дождитесь отдельного нажатия кнопки подтверждения.
$cart = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8000/api/sessions/$sessionId/cart/proposals/$($proposal.proposal_id)/confirm" -ContentType 'application/json' -Body '{"confirm":true}'
$cart
```

Пример ответа на предложение (время и UUID меняются):

```json
{
  "proposal_id": "9b799450-e278-4387-8956-c46a9dab2f4d",
  "product_id": "demo-breaker-16a",
  "quantity": 2,
  "expires_at": "2026-09-23T12:10:00+00:00",
  "product": {
    "id": "demo-breaker-16a",
    "sku": "DEMO-004",
    "name": "Автоматический выключатель 1P C16 6 кА",
    "category": "Автоматы",
    "brand": "Демо",
    "unit": "шт",
    "price_kzt": 1950,
    "stock": 14,
    "properties": {"полюса": "1P", "ток": "16 А", "характеристика": "C", "отключающая способность": "6 кА"},
    "description": "Модульный автоматический выключатель."
  }
}
```

После подтверждения корзина содержит `items[0].quantity = 2`, `items[0].subtotal_kzt = 3900`, `total_kzt = 3900`. До подтверждения она остаётся пустой. Нехватка демо-остатка возвращает 409; просроченное или отменённое предложение тоже возвращает 409. Чужой `proposal_id` в другой сессии возвращает 404.

## Границы демо

Сессии и корзины живут только в памяти одного процесса: перезапуск очищает их, несколько worker-процессов не делят состояние. ID сессии сам по себе не является авторизацией; перед подключением реальной корзины нужны аутентификация, привязка сессии к пользователю, постоянное хранилище, синхронизация с актуальными ценами/остатками и серверная интеграция ekt.kz. Файл `data/products.json` можно заменить подготовленной выгрузкой той же схемы; сейчас приложение не обращается к ekt.kz.



