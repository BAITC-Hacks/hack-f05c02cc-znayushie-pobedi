"""Short answers grounded in published EKT purchase information.

The source is public and can change; review before a production release.
"""
import re

SOURCE_URL = "https://ekt.kz/include/ses.php"


def answer_purchase_terms(question: str) -> dict[str, str] | None:
    text = question.casefold()
    if re.search(r"минимальн|мин\.?(?:имум)?\s*(?:парт|заказ)|мелк(?:ая|им)\s*опт", text):
        return {"topic": "minimum_order", "answer": "Единая минимальная партия в опубликованных условиях не указана. Она может зависеть от товара; назовите артикул и город, чтобы уточнить условие у менеджера.", "source_url": SOURCE_URL}
    if re.search(r"оплат|платеж|рассрочк", text):
        return {"topic": "payment", "answer": "По опубликованным условиям EKT физлица могут оплатить картой онлайн, наличными при получении или при самовывозе. Для юрлиц указан счёт с переводом на расчётный счёт; условия для конкретного заказа стоит уточнить при оформлении.", "source_url": SOURCE_URL}
    if re.search(r"достав|самовывоз|привез", text):
        return {"topic": "delivery", "answer": "По опубликованным условиям EKT доставка зависит от города и заказа. Для Алматы указаны отдельные условия; стоимость и сроки для других городов согласуются с менеджером по адресу, весу и объёму. Назовите город, чтобы уточнить детали.", "source_url": SOURCE_URL}
    return None
