"""Run: uvicorn app.main:app --reload"""
import html
import os
import re

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .assistant import answer
from .catalog import Catalog
from .models import ChatRequest, ChatResponse, ConfirmRequest, Proposal, ProposalRequest
from .sessions import SessionStore
from .terms import answer_purchase_terms

load_dotenv(".env.local")
load_dotenv(".env")

catalog = Catalog()
store = SessionStore(catalog)
app = FastAPI(title="EKT catalog assistant demo", version="0.2.0")
origins = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST", "DELETE"], allow_headers=["Content-Type"])


@app.get("/health")
def health():
    return {"status": "ok", "catalog": "demo", "products": len(catalog.products)}


@app.get("/api/products/search")
def search_products(q: str = Query(min_length=1), limit: int = Query(5, ge=1, le=20)):
    return {"products": catalog.search(q, limit), "source": "demo-json"}


@app.get("/api/products/{product_id}")
def get_product(product_id: str):
    product = catalog.get(product_id)
    if product is None:
        raise HTTPException(404, "Unknown product")
    return product


@app.get("/api/products/{product_id}/alternatives")
def get_alternatives(product_id: str):
    if catalog.get(product_id) is None:
        raise HTTPException(404, "Unknown product")
    return {"products": catalog.alternatives(product_id), "note": "Same-category suggestions, not verified interchangeable substitutes"}


@app.get("/api/purchase-terms")
def purchase_terms(q: str = Query(min_length=1)):
    result = answer_purchase_terms(q)
    if result is None:
        raise HTTPException(404, "No verified purchase terms for that question")
    return result


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    session = store.get(request.session_id) if request.session_id else store.create()
    terms = answer_purchase_terms(request.message)
    if terms is not None:
        return {"session_id": session.id, "answer": terms["answer"] + "\nИсточник: " + terms["source_url"], "products": [], "pending_action": None}
    products = catalog.search(request.message)
    if not products and session.last_product_ids:
        previous = catalog.get(session.last_product_ids[0])
        if re.search(r"аналог|замен|похож", request.message.casefold()):
            products = catalog.alternatives(previous["id"]) if previous else []
        elif re.search(r"налич|цен|характер|сколько|подроб", request.message.casefold()):
            products = [previous] if previous else []
    if products:
        session.last_product_ids = [p["id"] for p in products]
    text = answer(request.message, products)
    proposal = None
    # Add intent may create a proposal. Chat, including 'yes', can never confirm one.
    if re.search(r"\b(добавь|положи|добавить|положить)\b", request.message.casefold()):
        selected = [p for p in products if p["id"].casefold() in request.message.casefold() or p["sku"].casefold() in request.message.casefold()]
        if len(selected) == 1 and selected[0]["stock"] > store.get(session.id).cart.get(selected[0]["id"], 0):
            proposal = store.propose(session.id, selected[0]["id"], 1)
            text += "\nПодтвердите добавление отдельной кнопкой. Пока корзина не изменена."
        else:
            text += "\nДля добавления выберите товар и количество. Корзина не изменена."
    return {"session_id": session.id, "answer": text, "products": products, "pending_action": proposal}


def cart_with_url(request: Request, session_id: str, cart: dict) -> dict:
    return {**cart, "cart_url": str(request.url_for("demo_cart", session_id=session_id))}


@app.get("/api/sessions/{session_id}/cart")
def get_cart(session_id: str, request: Request):
    return cart_with_url(request, session_id, store.cart(session_id))


@app.get("/demo/cart/{session_id}", response_class=HTMLResponse, name="demo_cart")
def demo_cart(session_id: str):
    cart = store.cart(session_id)
    rows = "".join(
        f"<li><span>{html.escape(item['product']['name'])}</span> <strong>{item['quantity']} {html.escape(item['product']['unit'])}</strong> — {item['subtotal_kzt']:,} ₸</li>"
        for item in cart["items"]
    ) or "<li>Корзина пока пуста.</li>"
    return HTMLResponse(
        '<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Демо-корзина EKT</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:760px;margin:2rem auto;padding:0 1rem;color:#1e293b}'
        'li{padding:1rem 0;border-bottom:1px solid #ddd;display:flex;gap:1rem;flex-wrap:wrap;justify-content:space-between}ul{list-style:none;padding:0}'
        'strong{white-space:nowrap}small{color:#64748b}</style><h1>Демо-корзина</h1><small>Тестовые товары; это не корзина ekt.kz.</small>'
        f'<ul>{rows}</ul><h2>Итого: {cart["total_kzt"]:,} ₸</h2></html>'
    )


@app.post("/api/sessions/{session_id}/cart/proposals", response_model=Proposal, status_code=201)
def create_proposal(session_id: str, request: ProposalRequest):
    return store.propose(session_id, request.product_id, request.quantity)


@app.post("/api/sessions/{session_id}/cart/proposals/{proposal_id}/confirm")
def confirm_proposal(session_id: str, proposal_id: str, body: ConfirmRequest, request: Request):
    return cart_with_url(request, session_id, store.confirm(session_id, proposal_id, body.confirm))


@app.delete("/api/sessions/{session_id}/cart/proposals/{proposal_id}", status_code=204)
def cancel_proposal(session_id: str, proposal_id: str):
    store.cancel(session_id, proposal_id)
